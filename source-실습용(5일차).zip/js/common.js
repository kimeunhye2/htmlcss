window.addEventListener("load", function(){
    this.setTimeout(scrollTo, 0, 0, 0, 1);
}, false);

window.addEventListener("orientationchange", function(){
    this.setTimeout(scrollTo, 0, 0 ,0, 1);
}, false);